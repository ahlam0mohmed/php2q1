const express=require("express");
const app=express();
const server=require('http').createServer(app);
const io=require("socket.io")(server,{cors:{origin:"*"}})
app.set('view engine','ejs');


app.get("/",(req,res)=>{
    res.render("home");
    //res.send("<h1>hello Coding Acadmey</h1>")
})

server.listen("3000");
console.log("server connected ");


io.on("connection",(s)=>{

console.log("user connected sucessful with socket id : "+s.id);

s.on("message",(msg)=>{
    console.log("from user : "+msg);

    s.broadcast.emit("message",msg);
});



});